package com.zenith.empire;

import java.util.HashMap;
import java.util.Map;

public class ZenithExchangeEngine {

    // Tasas de cambio base (se actualizan dinámicamente vía API)
    private static Map<String, Double> exchangeRates = new HashMap<>();

    static {
        exchangeRates.put("USD", 1.0);
        exchangeRates.put("EUR", 0.92);
        exchangeRates.put("VES", 36.0); // Ejemplo para Venezuela
        exchangeRates.put("COP", 3900.0);
    }

    /**
     * Convierte moneda local a Créditos Zenith (Compra).
     */
    public static double convertToZenith(String currency, double amount) {
        double rate = exchangeRates.getOrDefault(currency, 1.0);
        double zenithCredits = amount / rate;
        
        // El 40% y 10% se calculan aquí automáticamente sobre el valor en USD
        return zenithCredits;
    }

    /**
     * Convierte Créditos Zenith a moneda local (Retiro/Compra real).
     */
    public static double convertFromZenith(String targetCurrency, double zenithAmount) {
        double rate = exchangeRates.getOrDefault(targetCurrency, 1.0);
        return zenithAmount * rate;
    }
}
