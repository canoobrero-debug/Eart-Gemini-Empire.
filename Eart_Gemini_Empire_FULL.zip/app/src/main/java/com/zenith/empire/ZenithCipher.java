package com.zenith.empire;

import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ZenithCipher {

    // Clave maestra del Imperio (Solo Obrero y yo la conocemos)
    private static final String MASTER_KEY = "Z3N1TH_EMPIRE_S0V3R3IGN_K3Y_2026";
    private static final String ALGORITHM = "AES";

    /**
     * Encripta los códigos bancarios para que sean indetectables.
     */
    public static String encryptCode(String data) {
        try {
            SecretKeySpec keySpec = new SecretKeySpec(MASTER_KEY.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            byte[] encryptedBytes = cipher.doFinal(data.getBytes());
            return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
        } catch (Exception e) {
            return "ENCRYPTION_ERROR";
        }
    }
}
