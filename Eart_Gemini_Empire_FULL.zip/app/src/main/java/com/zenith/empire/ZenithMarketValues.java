package com.zenith.empire;

import java.util.HashMap;
import java.util.Map;

public class ZenithMarketValues {
    // Espejo exacto de precios de TikTok
    public static final Map<Integer, Double> COIN_PACKS = new HashMap<>();
    
    static {
        COIN_PACKS.put(5, 0.05);      // 5 monedas
        COIN_PACKS.put(70, 0.99);     // 70 monedas
        COIN_PACKS.put(350, 4.99);    // 350 monedas
        COIN_PACKS.put(700, 9.99);    // 700 monedas
        COIN_PACKS.put(7000, 99.99);  // 7000 monedas
    }

    /**
     * Aplica la Ley del Soberano: 40% para Obrero, 10% Reserva.
     * Se ejecuta en cada compra de monedas de la tienda.
     */
    public static void processCoinPurchase(int coinAmount) {
        double price = COIN_PACKS.get(coinAmount);
        double sovereignCut = price * 0.40;
        double reserveVault = price * 0.10;
        
        ZenithFinanceProtocol.distributeFunds(sovereignCut, reserveVault);
    }
}
