package com.zenith.empire;

import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import java.util.concurrent.Executor;

public class ZenithBioLock {

    /**
     * Activa el escudo biométrico para autorizar pagos reales.
     */
    public void authenticateSovereign(FragmentActivity activity, Executor executor, BiometricPrompt.AuthenticationCallback callback) {
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("AUTORIZACIÓN IMPERIAL")
                .setSubtitle("Se requiere identidad soberana para liquidar fondos")
                .setNegativeButtonText("Cancelar")
                .build();

        BiometricPrompt biometricPrompt = new BiometricPrompt(activity, executor, callback);
        biometricPrompt.authenticate(promptInfo);
    }
}
