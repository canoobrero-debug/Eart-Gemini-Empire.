package com.zenith.empire;

public class ZenithCoin {
    public static final String SYMBOL = "ZNC";
    public static final double USD_VAL = 0.10; // 10 Zenith Coins = 1 Dólar

    /**
     * Procesa la compra de monedas. 
     * Aquí se aplica tu regla: 40% a tu cuenta, 10% a reserva.
     */
    public static void purchaseCoins(String userId, double usdAmount) {
        double sovereignShare = usdAmount * 0.40;
        double reserveShare = usdAmount * 0.10;
        
        ZenithFinanceProtocol.distributeFunds(sovereignShare, reserveShare);
        // El resto se convierte en ZNC para el usuario
    }
}
