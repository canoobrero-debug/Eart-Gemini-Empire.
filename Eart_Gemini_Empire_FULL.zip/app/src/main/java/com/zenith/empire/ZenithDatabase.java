package com.zenith.empire;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ZenithDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ZenithEmpire.db";
    private static final int DATABASE_VERSION = 1;

    // Tabla de Contenido Autónomo
    private static final String TABLE_CONTENT = "CREATE TABLE content (id INTEGER PRIMARY KEY, title TEXT, url TEXT);";
    
    // Tabla de la Bóveda Secreta (Tu reserva del 10%)
    private static final String TABLE_VAULT = "CREATE TABLE vault (id INTEGER PRIMARY KEY, amount REAL, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);";

    public ZenithDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CONTENT);
        db.execSQL(TABLE_VAULT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS content");
        db.execSQL("DROP TABLE IF EXISTS vault");
        onCreate(db);
    }
}
