package com.zenith.empire;

public class ZenithEconomyRules {
    
    // EL "QUIÉREME" SIEMPRE VALDRÁ 1 MONEDA IMPERIAL (ZNC)
    public static final int PRECIO_QUIEREME = 1; 

    /**
     * Limita la generación automática de precios.
     * Ningún regalo común superará los precios de la competencia.
     */
    public static int getSafePrice(int originalPrice) {
        // Si la IA intenta crear un regalo muy caro, este filtro lo baja
        // para asegurar que el pueblo pueda comprarlo.
        return Math.min(originalPrice, 30000); // El tope máximo es el 'León'
    }

    /**
     * Procesa el 40% para el Soberano incluso en regalos de 1 moneda.
     * La acumulación de millones de transacciones de 1 moneda es lo que llena la bóveda.
     */
    public static void processPopularTransaction(int coins) {
        double usdValue = coins * 0.014;
        ZenithFinanceProtocol.distributeFunds(usdValue * 0.40, usdValue * 0.10);
    }
}
