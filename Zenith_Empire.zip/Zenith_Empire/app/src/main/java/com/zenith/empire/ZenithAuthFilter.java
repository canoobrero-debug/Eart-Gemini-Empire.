package com.zenith.empire;

import android.util.Log;

public class ZenithAuthFilter {

    private static final double UMBRAL_AUTORIZACION = 1000000000.0; // 1,000 Millones

    /**
     * Determina si la transferencia requiere la huella del Soberano o es Autónoma.
     */
    public static boolean requiresSovereignAuth(double amount) {
        if (amount >= UMBRAL_AUTORIZACION) {
            Log.d("ZenithBank", "ALERTA: Monto crítico. Requiere Biometría del Obrero.");
            return true;
        } else {
            Log.d("ZenithBank", "Transferencia Autónoma: Liquidando fondos de inmediato.");
            return false;
        }
    }
}
