package com.zenith.empire;

import java.util.ArrayList;
import java.util.List;

public class ZenithPriceTable {

    public static List<CoinPackage> getCompetitiveCatalog() {
        List<CoinPackage> p = new ArrayList<>();
        
        // PAQUETES DE ENTRADA (Paridad con TikTok)
        p.add(new CoinPackage(5, 0.05, "Bronce"));
        p.add(new CoinPackage(70, 0.95, "Bronce")); // 4 centavos menos que TikTok

        // PAQUETES DE COMPETENCIA (Más monedas por menos dinero)
        p.add(new CoinPackage(350, 4.49, "Plata"));  // TikTok: .99 | Zenith: .49
        p.add(new CoinPackage(700, 8.99, "Plata"));  // TikTok: .99 | Zenith: .99

        // PAQUETES DE ÉLITE (El golpe maestro)
        p.add(new CoinPackage(3500, 44.99, "Oro"));  // Ahorro real para el usuario
        p.add(new CoinPackage(7000, 89.99, "Platino")); // El paquete más vendido de TikTok aquí es más barato

        // PAQUETES SOBERANOS (Precios de Gran Escala)
        p.add(new CoinPackage(17500, 189.99, "Imperial"));
        p.add(new CoinPackage(70000, 699.99, "Soberano")); 
        p.add(new CoinPackage(150000, 1499.99, "Zenith King")); // Máximo valor por inversión
        
        return p;
    }

    /**
     * Aunque el precio es menor, atraemos 10 veces más usuarios.
     * Tu 40% se calcula sobre el total bruto de estas ventas masivas.
     */
    public static void processImperialSale(double usdAmount) {
        ZenithFinanceProtocol.distributeFunds(usdAmount * 0.40, usdAmount * 0.10);
    }
}
