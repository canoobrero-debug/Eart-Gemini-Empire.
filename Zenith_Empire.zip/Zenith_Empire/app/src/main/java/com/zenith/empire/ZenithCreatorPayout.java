package com.zenith.empire;

public class ZenithCreatorPayout {

    private static final int MIN_FOLLOWERS = 2000;
    private static final double INITIAL_THRESHOLD = 100.00; // Primer retiro obligatorio
    private static final double SUBSEQUENT_MINIMUM = 5.00;  // Retiros después del primero

    /**
     * Valida el retiro basado en el historial del ciudadano.
     */
    public static boolean validateWithdrawal(String userId, int followers, double amount, boolean hasWithdrawnBefore) {
        
        // 1. Filtro de Influencia (Siempre activo)
        if (followers < MIN_FOLLOWERS) {
            return false; 
        }

        // 2. Lógica de "Primera Meta"
        if (!hasWithdrawnBefore) {
            if (amount < INITIAL_THRESHOLD) {
                // Mensaje: "Tu primer retiro debe ser de al menos 00"
                return false;
            }
        } else {
            // 3. Lógica de "Libertad Imperial"
            if (amount < SUBSEQUENT_MINIMUM) {
                // Mensaje: "Monto mínimo de retiro: "
                return false;
            }
        }

        return true;
    }
}
