package com.zenith.empire;

public class ZenithUserAuth {
    /**
     * Crea un nuevo ciudadano del imperio.
     * Genera automáticamente su billetera y su ID único.
     */
    public void registerCitizen(String name, String email, String country) {
        String citizenId = "ZEN-" + System.currentTimeMillis();
        
        // Crear cuenta bancaria física vinculada dentro de Zenith
        ZenithExchangeEngine.createAccount(citizenId, country);
        
        // Notificar al Soberano del nuevo súbdito
        ZenithNotify.sendImperialAlert(null, "Nuevo Ciudadano", name + " se ha unido al Imperio.");
    }
}
