package com.zenith.empire;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class ZenithCloudConfig {

    // Instancias globales para el Imperio
    public static FirebaseAuth mAuth = FirebaseAuth.getInstance(); // Para usuarios
    public static FirebaseFirestore db = FirebaseFirestore.getInstance(); // Para datos/monedas
    public static FirebaseStorage storage = FirebaseStorage.getInstance(); // Para videos HD

    /**
     * Inicializa la conexión segura con el servidor del Imperio.
     * Garantiza que el 40% de Obrero se registre antes de cualquier otra operación.
     */
    public static void connectToEmpireCloud() {
        // Establecer persistencia de datos (funciona incluso sin internet temporal)
        db.getFirestoreSettings().isPersistenceEnabled();
    }
}
