package com.zenith.empire;

public class ZenithFanLevels {
    
    // El regalo "Quiéreme" es la base del sistema
    public static final String STATIC_GIFT_NAME = "Quiéreme";
    public static final int QUIEREME_PRICE = 50; // ZNC fijo

    /**
     * Gestiona el nivel de lealtad.
     * Cuantos más "Quiéreme" envía el usuario, más alto es su rango en el Imperio.
     */
    public static void upgradeFanLevel(String userId, String creatorId) {
        // Al procesar el pago del "Quiéreme":
        // 40% para Obrero (Soberano)
        // 10% para la Reserva Secreta
        double commission = QUIEREME_PRICE * 0.14 * 0.40; 
        ZenithFinanceProtocol.addSovereignProfit(commission);
        
        // Aumentar nivel de medalla del usuario
    }
}
