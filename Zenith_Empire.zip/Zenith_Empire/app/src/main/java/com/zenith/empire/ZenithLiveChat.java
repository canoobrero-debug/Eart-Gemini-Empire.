package com.zenith.empire;

import java.util.List;

public class ZenithLiveChat {
    /**
     * Filtra mensajes en tiempo real durante la batalla.
     * Los mensajes de quienes envían regalos de más de 10 ZNC resaltan en dorado.
     */
    public void processChatMessage(String userId, String message, boolean isGifter) {
        if (isGifter) {
            // Animación especial en el chat para el 'Patrocinador'
            showGoldMessage(userId, message);
        }
        // Conexión directa con el motor de batalla para coordinar ataques
    }
}
