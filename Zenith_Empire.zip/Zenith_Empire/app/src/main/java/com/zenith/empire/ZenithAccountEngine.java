package com.zenith.empire;

import java.util.Random;

public class ZenithAccountEngine {

    // Prefijo de Banco Soberano Zenith (ZE)
    private static final String BANK_CODE = "ZENH"; 
    private static final String COUNTRY_CODE = "ZE";

    /**
     * Genera un número de cuenta autónomo y un código de Pago Móvil.
     */
    public static String generateSovereignAccount(String userId) {
        Random random = new Random();
        
        // Número de cuenta de 10 dígitos único
        long accountNumber = 1000000000L + (long)(random.nextDouble() * 9000000000L);
        
        // Formato IBAN Imperial: ZE + Dígitos Control + BANK_CODE + Account
        String fullIban = COUNTRY_CODE + "98" + BANK_CODE + accountNumber;
        
        return fullIban;
    }

    /**
     * Genera el ID para Pago Móvil y transacciones rápidas.
     */
    public static String generateMobilePayId(String phoneNumber) {
        // Vincula el número de teléfono al nodo financiero del imperio
        return "ZEN-" + phoneNumber;
    }
}
